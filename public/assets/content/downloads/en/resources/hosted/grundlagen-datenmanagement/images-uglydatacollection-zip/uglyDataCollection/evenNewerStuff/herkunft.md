Images

00540901.jpg - https://www.getty.edu/art/collection/objects/4747/unknown-maker-a-duck-a-rooster-and-a-goose-cretan-1510-1520/  - No Copyright USA
00938201.jpg - https://www.getty.edu/art/collection/objects/8236/attributed-to-the-clusium-group-one-fragment-of-a-duck-askos-etruscan-about-400-bc/ - No Copyright USA
15896001.jpg - https://www.getty.edu/art/collection/objects/144782/charles-francois-daubigny-le-marais-aux-canards-french-plate-1858-1862-print-1921/ - No Copyright USA

20210712_080947_entenhausen.jpg - eigenes Bild
20210712_080947_entenhausenCorr.jpg - eigenes Bild, selbst bearbeitet

Dame_Duck's_lecture_pg_6.jpg - https://commons.wikimedia.org/wiki/File:Dame_Duck%27s_lecture_pg_6.jpg - Public Domain USA

DSC_5248_IslandOstfjorde Djúpivogur.jpg/dng - eigenes Bild
DSC_5255_IslandOstfjorde Djúpivogur WIS.jpg/dng/tiff - eigenes Bild

Duck_netsuke-Ethno_BHM_262-P6141097-gradient.jpg - https://commons.wikimedia.org/wiki/File:Duck_netsuke-Ethno_BHM_262-P6141097-gradient.jpg - CC BY-SA 2.0, 3.0 FR

EierlegendeWollmilchSau.jpg - https://commons.wikimedia.org/wiki/File:EierlegendeWollmilchSau.jpg - CC BY-SA 3.0 (+DE)

Eierlegendewollmilchsau-Claire-Adele-02.jpg - http://www.claireadele.com/projects/eierlegendewollmilchsau-illustration/

Stamp_of_Albania_-_2000_-_Colnect_370816_-_Donald_Duck_and_Daisy_Duck.jpeg - https://commons.wikimedia.org/wiki/File:Stamp_of_Albania_-_2000_-_Colnect_370816_-_Donald_Duck_and_Daisy_Duck.jpeg - Public Domain

Wollmilchsau.jpg - https://commons.wikimedia.org/wiki/File:Wollmilchsau.jpg - CC BY-SA 2.5
Wollmilchsau.png - https://commons.wikimedia.org/wiki/File:Wollmilchsau.png - CC BY-SA 2.0


----
Postcards

01 - https://www.hippostcard.com/listing/malmo-sweden-to-pasco-washington-usa-2002-die-cut-postcard-ducks-geese/29141918
02 - https://www.hippostcard.com/listing/united-kingdom-post-card-duckings-by-the-rivers-edge-by-constant-artz/33713484
03 - https://www.hippostcard.com/listing/postcard-daffy-duck-warner-brothers-i-live-down-by-pond-drop-in-pc1757/26347659
04 - https://www.hippostcard.com/listing/french-walt-disney-donald-duck-character-nephews-c1950s-pc-by-tobler-chocolate/31702830


----
3d

clay_duck.zip - https://sketchfab.com/3d-models/clay-duck-39259b33b5b24361b91f2211f3e71691 - CC BY

ypm-ant248958.zip - https://sketchfab.com/3d-models/ypm-ant248958-99bc606872cb44299b3041dc360ea5f6 - CC BY


